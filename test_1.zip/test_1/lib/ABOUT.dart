import 'dart:html';

import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:carousel_slider/carousel_slider.dart';



class ABOUT extends StatelessWidget {
  const ABOUT({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Container(
        width: 1800,
        height: 2500,
        color: Colors.black,
    child: SingleChildScrollView(
    child: Column(
    children: [
      Text(
    'WELCOME TO THE VAPE CITY CARDIFF!',
    style: TextStyle(
    fontFamily: 'Arial',
    fontSize: 25,
    color: Colors.white,
    height: 3,
    ),
    textAlign: TextAlign.center),

      Text('We are a family run business of which all were former smokers but have successfully quit for many years by\n using electronic vaping devices. We loved it so much we decided to set up shop and help spread the word\n in the hope to get others to quit tobacco by switching to nicer alternative. Vape City Cardiff stocks a great\n selection of vaping products from starter kits to more advance levels. We have a large selection of premium grade juices\n all available to try before purchase so you get exactly what you need..',
    style: TextStyle(
    fontFamily: 'Arial',
    fontSize: 20,
    color: Colors.white),
          textAlign: TextAlign.center),
      
      Text('We’re so confident you won’t find a better service and will price match any local brick & motar store within\n a 5 mile radius.You’ll find our  vape shop situated in Cardiff City Road, so do pop in for a chat and advice.',
          style: TextStyle(
              fontFamily: 'Arial',
              fontSize: 20,
              color: Colors.white),
          textAlign: TextAlign.center),

      Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Image.asset('assets/shop1.jpg', alignment: Alignment.centerLeft, width: 900, height: 370),
    ],
      ),


    Container(
      child: Column(
        children: [
          Text('Vape City Cardiff is a well established, well known vape shop in Cardiff. At Vape City our aim is to provide quality vape shop services including\npremium E-liquid from the USA and UK, vape mods and vape accessories.\n We can provide a quality service across Cardiff and many of the surrounding areas.',
              style: TextStyle(
                  fontFamily: 'Arial',
                  fontSize: 20,
                  color: Colors.white,
              height: 2),
              textAlign: TextAlign.center),
        ],
      ),
    ),
    
    
    
    



    Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Image.asset('assets/mod.png', alignment: Alignment.centerLeft, width: 900, height: 370),
        Text(' \u2022 Vape Starter Kits\n \u2022 Premium E-Liquid\n \u2022 Vape Mods\n \u2022 E-liquid\n \u2022 Vape Accesories\n \u2022 Vape Coils',style: TextStyle(
            fontFamily: 'Arial',
            fontSize: 25,
            color: Colors.white),),

      ],
    ),



      Container(
        child: Column(
          children: [
            Text('We also carry a large selection of CBD Vape Oils.\nAs with any herbal supplement please check with your doctor and do your own research before use.\nWe are unable to recommend dose or diagnose patients, always consult a medical professional..',
                style: TextStyle(
                    fontFamily: 'Arial',
                    fontSize: 20,
                    color: Colors.white,
                    height: 2),
                textAlign: TextAlign.center),
          ],
        ),
      ),

      Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Image.asset('assets/oil2.jpg', alignment: Alignment.centerLeft, width: 900, height: 370),

        ],
      ),


      Container(
        color: Colors.deepOrange,
        height: 300,
        width: 1600,
        child: Row(
          children:<Widget> [
            Expanded(child:
            Text('OPENING HOURS\n Monday-Sunday 09.00-23.00',
                style: TextStyle(
                    fontFamily: 'Arial',
                    fontSize: 20,
                    color: Colors.white,
                    height: 2),
                textAlign: TextAlign.center),
            ),

            Expanded(child:
            Text('VAPE CITY CARDIFF\n113 City Rd\nCardiff\nCF24 3BN',
                style: TextStyle(
                    fontFamily: 'Arial',
                    fontSize: 20,
                    color: Colors.white,
                    height: 2),
                textAlign: TextAlign.center),
            ),

            Expanded(child:
            Text('CONTACT US\n vapecity@mail.com\n 07456235456',
                style: TextStyle(
                    fontFamily: 'Arial',
                    fontSize: 20,
                    color: Colors.white,
                    height: 2),
                textAlign: TextAlign.center),
            ),




          ],


        ),
      ),






    ],
    ),
    ),


      ),

      );



  }
}