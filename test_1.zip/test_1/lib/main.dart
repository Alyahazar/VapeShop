import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'HOME.dart';
import 'ABOUT.dart';
import 'CONTACT.dart';

void main() => runApp(MaterialApp(home:MyApp()));


class MyApp extends StatelessWidget {
  @override

  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'VAPE CITY CARDIFF',
      theme: ThemeData(scaffoldBackgroundColor: Colors.black
      ),
      home: CarouselSliderExample(),
    );

  }
}






class CarouselSliderExample extends StatelessWidget {
  @override
  Widget build(BuildContext context) {

    return MaterialApp(
      home: DefaultTabController(
        length: 3,
        child: Scaffold(
          appBar: AppBar(
            bottom: TabBar(
              labelColor: Colors.white,
              unselectedLabelColor: Colors.grey,
              labelStyle: TextStyle(fontSize: 13.0),
              indicatorColor: Colors.lime,
              tabs: [
                Tab(text: 'HOME',icon: Icon(Icons.home)),
                Tab(text: 'ABOUT US',icon: Icon(Icons.people)),
                Tab(text: 'CONTACT US',icon: Icon(Icons.contact_phone)),
              ],
            ),
            toolbarHeight: 280,
            backgroundColor: Colors.black,
            leading: Image.asset('Assets/vape.jpg'),
            leadingWidth: 200,
            centerTitle: true,
            title:  Column(
              children: <Widget> [
                Text('FREE DELIVERY ON ALL ORDERS OVER £35',
                  style: TextStyle(
                      color: Colors.deepOrange, fontSize: 20
                  ),
                ),
                Text('Call us on 075152555452',
                  style: TextStyle(
                      color: Colors.deepOrange, fontSize: 20
                  ),
                ),
                Text('VAPE CITY CARDIFF',
                  style: TextStyle(
                      color: Colors.deepOrange, fontSize: 90
                  ),
                ),
              ],
            ),
          ),


          

          body: TabBarView(
            children: [
              HOME(),
              ABOUT(),
              CONTACT(),

    ],
    ),
    ),
    ),
    );

  }
}

