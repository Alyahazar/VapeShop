import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:test_1/CONTACT.dart';


class CONTACT extends StatelessWidget {
  const CONTACT({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: <Widget>[
          Text('Contact',
            style: TextStyle(
              fontSize: 32.0,
              fontWeight: FontWeight.bold,

            ),
          ),
          Text('Fill out the form below or contacts the shop directly during opening hours on 0745632546...we are here to help.'),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10.0),
            child: Column(
              children: <Widget>[
                SizedBox(height: 2.0),
                TextField(
                  decoration: InputDecoration(
                    filled: true,
                    hintText: 'Name',
                    border: InputBorder.none,
                  ),
                ),
                SizedBox(height: 2.0),
                TextField(
                  decoration: InputDecoration(
                    filled: true,
                    hintText: 'Email',
                    border: InputBorder.none,
                  ),
                ),
                SizedBox(height: 3.0),
                TextField(
                  maxLines: 7,
                  decoration: InputDecoration(
                    filled: true,
                    hintText: 'Message',
                    border: InputBorder.none,
                  ),
                ),
                SizedBox(height: 2.5),
                MaterialButton(
                  height: 3.0,
                  minWidth: double.infinity,
                  color: Colors.blue,
                  onPressed: () {},
                  child: Text('SUBMIT', style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Colors.white,

                  ),
                  ),
                ),


              ],
            ),
          ),


        ],
      ),
    );
  }
}
